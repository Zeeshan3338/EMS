﻿using DomainEntity.ModelDTOs;
using Infrastructure.IServices;
using Microsoft.AspNetCore.Mvc;

namespace WebUI.Controllers
{
    public class QuizController : Controller
    {
        private readonly IExamService _examService;
        public QuizController(IExamService examService)
        {
            _examService = examService;
        }
        public IActionResult Index()
        {
            return View();
        }
        public List<QuestionDTO> GetAllQuestions()
        {
            return _examService.GetQuiz();
        }
    }
}
