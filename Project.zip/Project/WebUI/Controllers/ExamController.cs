﻿using DomainEntity.ModelDTOs;
using Infrastructure.IServices;
using Microsoft.AspNetCore.Mvc;

namespace WebUI.Controllers
{
    public class ExamController : Controller
    {
        private readonly IExamService _examService;
        public ExamController(IExamService examService)
        {
            _examService = examService;
        }
        public IActionResult Exam()
        {
            return View();
        }
        public IActionResult Questions()
        {
            return View();
        }
        [HttpPost]
        public JsonResult CreateExam(Exam exmObject)
        {
            return Json(_examService.CreateExam(exmObject));
        }

        public List<Exam> GetExamList() { 
            return _examService.GetExams(); 
        }
        public List<DomainEntity.ModelDTOs.QuestionType> GetTypes()
        {
            return _examService.GetType();
        }
        [HttpPost]
        public JsonResult CreateQuestion(Question Obj)
        {
            return Json(_examService.CreateQuestion(Obj));
        }
        public List<QuestionDTO> GetAllQuestions()
        {
            return _examService.GetAllQuestions();
        }
    }
}
