﻿using DomainEntity.ModelDTOs;
using Infrastructure.IServices;
using Infrastructure.Services;
using Microsoft.AspNetCore.Mvc;
using System.ComponentModel;

namespace WebUI.Controllers
{
    public class UserController : Controller
    {
        private readonly IUserService _userService;
        public UserController(IUserService userService)
        {
            _userService = userService;
        }
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult User()
        {
            return View();
        }
        public  List<User> GetUsers()
        {
           return  _userService.GetUsers();
        }
        [HttpPost]
        public JsonResult CreateUser(User Obj)
        {
            return Json(_userService.CreateUser(Obj));
        }
    }
}
