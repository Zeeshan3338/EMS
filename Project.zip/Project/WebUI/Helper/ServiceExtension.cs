﻿using Infrastructure.IRepositories;
using Infrastructure.IServices;
using Infrastructure.Repositories;
using Infrastructure.Services;
using Reposotories.IRepositories;
using Reposotories.Repositories;

namespace EMS.Helper
{
    public static class ServiceExtension
    {
        public static void InjectServices(this IServiceCollection services)
        {
            services.AddScoped<IDatabaseConnectionService>(e => new DatabaseConnectionService("server=DESKTOP-A435Q21\\SQLEXPRESS; database=EMS; Integrated Security=true; Encrypt=false"));
            services.AddScoped<IUserRepository, UserRepository>();
            services.AddScoped<IUserService, UserService>();
            services.AddScoped<IExamRepository, ExamRepository>();
            services.AddScoped<IExamService, ExamService>();
        }
    }
}
