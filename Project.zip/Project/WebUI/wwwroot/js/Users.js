﻿$(document).ready(function () {
    console.log("ready!");
    bindUsers();
});

function bindUsers(){
    $.ajax({
        url: '/User/GetUsers',
        method: 'GET',
        dataType: 'json',
        success: function (data) {
            // Callback function to handle the API response
            var table = $("#userTable tbody").html('');
            $.each(data, function (index, item) {
                index += 1;
                var row = $("<tr>");
                row.append($("<td>").text(index));
                row.append($("<td>").text(item.name));
                row.append($("<td>").text(item.email));
                row.append($("<td>").text(item.phone));
                row.append($("<td>").text((item.gender == true ? 'Male' : 'Female')));
                row.append($("<td>").text(item.role));
                table.append(row);
            });
        },
        error: function (error) {
            console.error('Error fetching data from the API:', error);
        }
    })
}
function createUser() {
    data = {
        Name: $('#Name').val(),
        Email: $('#Email').val(),
        Phone: $('#Phone').val(),
        Gender: parseInt($('#Gender').val()),
        RoleId: parseInt($('#Role').val()),
        Password: $('#Password').val()
    }

    if ($('#Name').val() == '' || $('#Email').val() == '' || $('#Phone').val() == '' || $('#Password').val() == '') {
        alertify.error('Form is Empty.')
        return false;
    }
    $.ajax({
        type: "POST",
        url: "/User/CreateUser",
        data: data,
        success: function (response) {
            if (response == 1) alertify.success('User Successfully Created.');

            if (response == 0) alertify.error('Try again.');
            bindUsers();
            $('#Name, #Email, #Phone, #Password').val('');
        },
        error: function (xhr, status, error) {
            console.error("Error saving data:", status, error);
        }
    });
}