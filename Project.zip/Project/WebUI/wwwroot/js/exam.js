﻿$(document).ready(function () {
    bindExams();
    getTypes();
});
function createExam() {
    data = {
        Title: $('#Title').val(),
        ExamDate: $('#Date').val()
    }
    if ($('#Title').val() == '' || $('#Date').val()) {
        alertify.error('Form is Empty.')
        return false;
    }
    $.ajax({
        type: "POST",
        url: "/Exam/CreateExam", 
        data: data,
        success: function (response) {
            if (response == 1) alertify.success('Exam Successfully Created.');

            if (response == 0) alertify.error('Try again.');
            bindExams();
            clear();

        },
        error: function (xhr, status, error) {
            console.error("Error saving data:", status, error);
        }
    });
}
function bindExams() {
    $.ajax({
        url: '/Exam/GetExamList',
        method: 'GET',
        success: function (data) {
            // Callback function to handle the API response
            var table = $("#examTable tbody").html('');
            $.each(data, function (index, item) {
                index = index + 1;
                var row = $("<tr>");
                row.append($("<td>").text(index));
                row.append($("<td>").text(item.title));
                row.append($("<td>").text(DateFormate(item.examDate)));
                table.append(row);
            });
        },
        error: function (error) {
            console.error('Error fetching data from the API:', error);
        }
    })
}
function clear(){
    $('#Title, #Date').val('');
}
function DateFormate(isoTimestamp) {
    
    const date = new Date(isoTimestamp);
    const day = date.getDate().toString().padStart(2, '0');
    const month = (date.getMonth() + 1).toString().padStart(2, '0'); // Note: Months are zero-based
    const year = date.getFullYear();
    const formattedDate = `${day}/${month}/${year}`;
    return formattedDate;
}
