﻿$(document).ready(function () {
    bindQuiz();
});
function bindQuiz() {
   
    $.ajax({
        type: "Get",
        url: "/Quiz/GetAllQuestions",
        success: function (response) {
            debugger;
            $.each(response, function (index, item) {
                index = index + 1;
                var string = '';
                debugger;
                $.each(item.options, function (idex, element) {
                    if (item.typeId == 2) {
                        string += '<div class="col-lg-3"><input type="text" id="html" name="fav_language"/></div><br>';
                    }else if (item.typeId == 4) {
                        string += '<div class="col-lg-3"><textarea  id="html" rows="4" cols="50" name="fav_language"/></div><br>';
                    }
                    else {
                        string += '<div class="col-lg-3"><input type="radio" id="html" name="fav_language" value="HTML"><label style="margin-left: 5px; color:#a78e8e;">' + element.optionText + '</label></div><br>';

                    }
                })
                

                const opt = '<div class="row mt-3"><label>'+index+'.  &nbsp;' + item.questionText + '</label><br> '+string+' </div>';
                $('.QuizArea').append(opt);

            });

        },
        error: function (xhr, status, error) {
            console.error("Error saving data:", status, error);
        }
    });
   
}