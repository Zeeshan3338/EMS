﻿$(document).ready(function () {
    getTypes();
    bindExamsInDDL();
    bindQuestions();
})

function getTypes() {
    $.ajax({
        url: '/Exam/GetTypes',
        method: 'GET',
        success: function (data) {
            var selectElement = $("#type").html('');
            $.each(data, function (index, value) {
                selectElement.append($("<option>", {
                    value: value.typeId,
                    text: value.type
                }));
            });
        },
        error: function (error) {
            console.error('Error fetching data from the API:', error);
        }
    })
}    
function bindExamsInDDL() {
    $.ajax({
        url: '/Exam/GetExamList',
        method: 'GET',
        success: function (data) {
            var selectElement = $("#exam").html('');
            $.each(data, function (index, value) {
                selectElement.append($("<option>", {
                    value: value.examId,
                    text: value.title
                }));
            });
        },
        error: function (error) {
            console.error('Error fetching data from the API:', error);
        }
    })
}
function AddOptions(param) {
    param = param == 1 ? 4 : param == 2 ? 1 : param == 3 ? 2 : 0;
    if (param == 0) {
        setTimeout(function () {
            $("#correctAnswer").attr("disabled", true);
        }, 500);

    } else {
        setTimeout(function () {
            $("#correctAnswer").attr("disabled", false);
        }, 500);
    }
    const string =
        '<div class="col-lg-3">' + 
           '<div class="input-group">' +
           '<input type="text" class="form-control myInput" placeholder="Enter Option" id="myInput_'+param+'" style="width:70%;">' + 
            '<div class="input-group-append">'+
            '<button class="btn btn-info"><i class="fa fa-plus"></i></button>' +
            '</div>' +
           '</div>' +
        '</div>';
    var html = '';
    for (var i = 0; i < param; i++) {
        html += string;
    }
    if (param == 1) {
        html = '';
    }
    $('.optionsArea').html(html);
}

function saveQuestion() {
    if (($('#type').val() == '' || $('#correctAnswer').val() == '') && $('#type').val() !== '4') {
        alertify.error('Form is Empty.')
        return false;
    }
    if ($('#type').val() !== '4' && $('#correctAnswer').val() == '') {
        alertify.error('Form is Empty.')
        return false;
    }
    var correctAnswer = $('#correctAnswer').val();

    var values = [];
    var isCorrectAnsEnter = false;
    $(".myInput").each(function () {
        if ($(this).val() !== '') {
            if (correctAnswer == $(this).val()) {
                values.push({ IsCorrect: true, OptionText: $(this).val() });
                isCorrectAnsEnter = true;
            } else {
                values.push({ IsCorrect: false, OptionText: $(this).val() })
            }
        }
    });
    if ($('#type').val() == 2) {
        isCorrectAnsEnter = true;
        values.push({ IsCorrect: true, OptionText: correctAnswer });
    }

    if (values.length == 0 && $('#type').val() !== '4') {
        alertify.error('Options can not be empty.')
        return false;
    }
    if (!isCorrectAnsEnter && $('#type').val() !== '4') {
        alertify.error('Please enter Correct Answer entered Options List.')
        return false;
    }
    data = {
        ExamId: $('#exam').val(),
        QuestionText: $('#QuestionText').val(),
        TypeId: $('#type').val(),
        Options: values
    }
    $.ajax({
        type: "POST",
        url: "/Exam/CreateQuestion",
        data: data,
        success: function (response) {
            if (response == 1) {
                alertify.success('Question Successfully Created.');
                $('#correctAnswer, #QuestionText , .myInput').val('')
                bindQuestions();
            }

            if (response == 0) alertify.error('Try again.');
        },
        error: function (xhr, status, error) {
            console.error("Error saving data:", status, error);
        }
    });

}

function bindQuestions() {
    $.ajax({
        url: '/Exam/GetAllQuestions',
        method: 'GET',
        success: function (data) {
            // Callback function to handle the API response
            var table = $("#questionTable tbody").html('');
            $.each(data, function (index, item) {
                index = index + 1;
                var row = $("<tr>");
                row.append($("<td>").text(index));
                row.append($("<td>").text(item.title));
                row.append($("<td>").text(item.questionText));
                row.append($("<td>").text(DateFormate(item.examDate)));
                row.append($("<td>").text(item.type));
                table.append(row);
            });
        },
        error: function (error) {
            console.error('Error fetching data from the API:', error);
        }
    })
}
function DateFormate(isoTimestamp) {

    const date = new Date(isoTimestamp);
    const day = date.getDate().toString().padStart(2, '0');
    const month = (date.getMonth() + 1).toString().padStart(2, '0'); // Note: Months are zero-based
    const year = date.getFullYear();
    const formattedDate = `${day}/${month}/${year}`;
    return formattedDate;
}
