﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace DomainEntity.ModelDTOs
{
    public class QuestionDTO
    {
        public QuestionDTO()
        {
            this.Options = new List<option>();
        }

        public int QuestionID { get; set; }
        public string Title { get; set; }
        public string QuestionText { get; set; }
        public DateTime ExamDate { get; set; }
        public int TypeId { get; set; }
        public string? Type { get; set; }
        public bool IsCorrect { get; set; }
        public string OptionText { get; set; }
        public List<option> Options { get; set; }
    }
   
}
