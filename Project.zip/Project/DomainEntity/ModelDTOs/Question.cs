﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomainEntity.ModelDTOs
{
    public class Question
    {
        public int ExamId { get; set; }
        public string QuestionText { get; set; }
        public int TypeId { get; set; }
        public List<option> Options { get; set; }
    }
    public class option
    {
        public bool IsCorrect { get; set; }
        public string OptionText { get; set; }
    }
}
