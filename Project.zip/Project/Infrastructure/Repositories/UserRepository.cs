﻿using Dapper;
using DomainEntity.ModelDTOs;
using Infrastructure.Services;
using Reposotories.IRepositories;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Reposotories.Repositories
{
    public class UserRepository : IUserRepository
    {
        private readonly IDatabaseConnectionService _DatabaseConnectionService;
        public UserRepository(IDatabaseConnectionService databaseConnection)
        {
            _DatabaseConnectionService = databaseConnection;
        }
        public List<User> GetUsers()
        {
            try
            {
                using (var _sqlConnection = _DatabaseConnectionService.CreateConnection())
                {
                    var list = _sqlConnection.Query<User>("select u.*,r.Role from Users u inner join Roles r on u.RoleId = r.Id", null, commandType: CommandType.Text).ToList();
                    _sqlConnection.Close();
                    return list;
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        public int CreateUser(User obj)
        {
            using (var _sqlConnection = _DatabaseConnectionService.CreateConnection())
            {

                var data = _sqlConnection.Execute("Insert into Users values('"+obj.Name+"','"+obj.Email+"','"+obj.Phone+"','"+obj.Password+"',"+(obj.Gender == true ? 1 : 0) +","+obj.RoleId + ")", commandType: CommandType.Text);
                _sqlConnection.Close();
                return data;
            }
        }

    }
}
