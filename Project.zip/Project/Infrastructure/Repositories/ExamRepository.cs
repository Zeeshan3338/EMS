﻿using Dapper;
using DomainEntity.ModelDTOs;
using Infrastructure.IRepositories;
using Infrastructure.Services;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Type = DomainEntity.ModelDTOs.QuestionType;

namespace Infrastructure.Repositories
{
    public class ExamRepository : IExamRepository
    {
        private readonly IDatabaseConnectionService _DatabaseConnectionService;
        public ExamRepository(IDatabaseConnectionService databaseConnection)
        {
            _DatabaseConnectionService = databaseConnection;
        }
        public int CreateExam(Exam obj)
        {
            using (var _sqlConnection = _DatabaseConnectionService.CreateConnection())
            {

                var data = _sqlConnection.Execute("insert into Exam values('"+ obj.Title + "','"+obj.ExamDate+"')", commandType: CommandType.Text);
                _sqlConnection.Close();
                return data;
            }
        }
        public List<Exam> GetExams()
        {
            using (var _sqlConnection = _DatabaseConnectionService.CreateConnection())
            {

                var data = _sqlConnection.Query<Exam>("GetEmployee", commandType: CommandType.StoredProcedure).ToList();
                _sqlConnection.Close();
                return data;
            }
        }
        public List<QuestionType> GetTypes()
        {
            using (var _sqlConnection = _DatabaseConnectionService.CreateConnection())
            {

                var data = _sqlConnection.Query<QuestionType>("GetQuestionType", commandType: CommandType.StoredProcedure).ToList();
                _sqlConnection.Close();
                return data;
            }
        }

        public int CreateQuestion(Question obj)
        {
            using (var _sqlConnection = _DatabaseConnectionService.CreateConnection())
            {

                var data = _sqlConnection.ExecuteScalar("insert into Questions output inserted.QuestionID values(" + obj.ExamId + ",'"+obj.QuestionText + "',"+ obj.TypeId + ")", commandType: CommandType.Text);
                _sqlConnection.Close();
                if (obj.Options != null)
                {
                    return CreateOptions(obj.Options, Convert.ToInt32(data));
                }
                else
                {
                    return Convert.ToInt32(data);
                }
              
            }
        }

        public int CreateOptions(List<option> obj,int QuestionId) {
            using (var _sqlConnection = _DatabaseConnectionService.CreateConnection())
            {
                int result = 0;
                foreach (var option in obj)
                {
                    result = _sqlConnection.Execute("insert into Options values(" + QuestionId + ",'"+ option.OptionText + "',"+(option.IsCorrect == false ? 0 : 1)+")", commandType: CommandType.Text);
                }
                _sqlConnection.Close();

                return result;
            }
        }

        public List<QuestionDTO> GetAllQuestions()
        {
            using (var _sqlConnection = _DatabaseConnectionService.CreateConnection())
            {

                var data = _sqlConnection.Query<QuestionDTO>("GetAllQuestions", commandType: CommandType.StoredProcedure).ToList();
                _sqlConnection.Close();
                return data;
            }
        }
        public List<QuestionDTO> GetQuiz()
        {
            using (var _sqlConnection = _DatabaseConnectionService.CreateConnection())
            {

                var data = _sqlConnection.Query<QuestionDTO>("GetQuiz", commandType: CommandType.StoredProcedure).ToList();
                _sqlConnection.Close();
                return data;
            }
        }

    }
}
