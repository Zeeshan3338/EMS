﻿using DomainEntity.ModelDTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Reposotories.IRepositories
{
    public interface IUserRepository
    {
         List<User> GetUsers();
        int CreateUser(User obj);
    }
}
