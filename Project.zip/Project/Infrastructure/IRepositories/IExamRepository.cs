﻿using DomainEntity.ModelDTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.IRepositories
{
    public interface IExamRepository
    {
         int CreateExam(Exam obj);
          List<Exam> GetExams();
        List<DomainEntity.ModelDTOs.QuestionType> GetTypes();
        int CreateQuestion(Question obj);
        List<QuestionDTO> GetAllQuestions();
        List<QuestionDTO> GetQuiz();
    }
}
