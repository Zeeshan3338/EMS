﻿using DomainEntity.ModelDTOs;
using Infrastructure.IRepositories;
using Infrastructure.IServices;
using Reposotories.IRepositories;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.Services
{
    public class ExamService : IExamService
    {
        private readonly IExamRepository _examRepository;
        public ExamService(IExamRepository examRepository)
        {
            _examRepository = examRepository;
        }

        public int CreateExam(Exam obj)
        {
            return _examRepository.CreateExam(obj);
        }
        public List<Exam> GetExams()
        {
            return _examRepository.GetExams();
        }
        public List<DomainEntity.ModelDTOs.QuestionType> GetType()
        {
            return _examRepository.GetTypes();
        }

        public int CreateQuestion(Question obj)
        {
            return _examRepository.CreateQuestion(obj);
        }
        public List<QuestionDTO> GetAllQuestions()
        {
           return _examRepository.GetAllQuestions();
        }
        public List<QuestionDTO> GetQuiz()
        {
            var data = _examRepository.GetQuiz();
            List<QuestionDTO> _quizList = new List<QuestionDTO>();
            foreach (var item in data)
            {
                var checkQuestion = _quizList.Find(p => p.QuestionID == item.QuestionID);
                if (checkQuestion != null)
                {
                    checkQuestion.Options.Add(new option { IsCorrect = item.IsCorrect, OptionText = item.OptionText });
                }
                else
                {
                    item.Options.Add(new option { IsCorrect = item.IsCorrect, OptionText = item.OptionText });
                    _quizList.Add(item);


                }
            }
            return _quizList;
        }

    }
}
