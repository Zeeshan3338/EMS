﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.Services
{
  
    public class DatabaseConnectionService : IDatabaseConnectionService
    {
        private SqlConnection _sqlConnection;
        private readonly string _connectionString;
        public DatabaseConnectionService(string connectionString)
        {
            _connectionString = connectionString;
            _sqlConnection = new SqlConnection(_connectionString);
        }
        public async Task<SqlConnection> CreateConnectionAsync()
        {
            if (_sqlConnection.State != System.Data.ConnectionState.Open)
            {
                _sqlConnection = new SqlConnection(_connectionString);
                await _sqlConnection.OpenAsync();
            }
            return await Task.FromResult(_sqlConnection);
        }

        public SqlConnection CreateConnection()
        {
            try
            {
                if (_sqlConnection.State != System.Data.ConnectionState.Open)
                {
                    _sqlConnection = new SqlConnection(_connectionString);
                    _sqlConnection.Open();
                }
                else
                {
                    _sqlConnection.Close();
                    _sqlConnection.Dispose();
                    _sqlConnection = new SqlConnection(_connectionString);
                    _sqlConnection.Open();
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return _sqlConnection;
        }
     
    }
}
