﻿using DomainEntity.ModelDTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.IServices
{
    public interface IExamService
    {
        int CreateExam(Exam obj);
        List<Exam> GetExams();
        List<DomainEntity.ModelDTOs.QuestionType> GetType();
        int CreateQuestion(Question obj);
        List<QuestionDTO> GetAllQuestions();
        List<QuestionDTO> GetQuiz();
    }
}
