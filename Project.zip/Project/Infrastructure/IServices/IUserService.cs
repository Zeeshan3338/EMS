﻿using DomainEntity.ModelDTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.IServices
{
    public interface IUserService
    {
         List<User> GetUsers();
        int CreateUser(User obj);
    }
}
